/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "can.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "canfestival.h"
#include "slavedic.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void CANFilter_Config(void);
void CAN_Start_Init(void);
void CAN2_Send_Test(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_CAN2_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */

  selectTimer(&htim3);
  selectCAN(&hcan2);
  // baud rate is not needed here, because it is set in CubeMX
  canInit(&slavedic_ObjDictData, UINT32_MAX);

  HAL_TIM_Base_Start_IT(&htim3);

  CANFilter_Config();
  CAN_Start_Init();

  setNodeId(&slavedic_ObjDictData, 1); // Set CANopen node id to be 1
  setState(&slavedic_ObjDictData, Initialisation); // Set NMT state to Initialisation
  setState(&slavedic_ObjDictData, Pre_operational); // Set NMT state to Pre_operational
  setState(&slavedic_ObjDictData, Operational); // Set NMT state to Operational

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    HAL_Delay(1000);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

void CANFilter_Config(void)
{
  CAN_FilterTypeDef  sFilterConfig;
  
  sFilterConfig.FilterBank = 0;                       // CAN过滤器编号，范围0-27
  sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;   // CAN过滤器模式，掩码模式或列表模式，这里选择掩码模式
  sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;  // CAN过滤器尺度，16位或32位，这里选择32位
  sFilterConfig.FilterIdHigh = 0x0000;                // 32位下，存储要过滤ID的高16位
  sFilterConfig.FilterIdLow  = 0x0000;                // 32位下，存储要过滤ID的低16位
  sFilterConfig.FilterMaskIdHigh = 0x0000;            // 掩码模式下，存储的是过滤器掩码的高16位
  sFilterConfig.FilterMaskIdLow  = 0x0000;            // 掩码模式下，存储的是过滤器掩码的低16位
  sFilterConfig.FilterFIFOAssignment = CAN_FILTER_FIFO0; // 报文通过过滤器的匹配后，存储到哪个FIFO，这里选择FIFO0
  sFilterConfig.FilterActivation = CAN_FILTER_ENABLE; // 激活过滤器
  sFilterConfig.SlaveStartFilterBank = 0;
  
  if (HAL_CAN_ConfigFilter(&hcan2, &sFilterConfig) != HAL_OK) 
  {
    Error_Handler();
  }
}

void CAN_Start_Init(void)
{
  if (HAL_CAN_Start(&hcan2) != HAL_OK) 
  {
    Error_Handler();
  }

  if (HAL_CAN_ActivateNotification(&hcan2, CAN_IT_RX_FIFO0_MSG_PENDING) !=  HAL_OK)
  {
    Error_Handler();
  }
}

void CAN2_Send_Test(void)
{
  uint32_t TxMailbox;
  uint8_t data[4] = {0x01, 0x02, 0x03, 0x04};

  CAN_TxHeaderTypeDef TxMessage;
  TxMessage.IDE = CAN_ID_STD;     // 设置ID类型，标准帧还是扩展帧，这里选择标准帧
  TxMessage.StdId = 0x111;        // 设置ID号
  TxMessage.RTR = CAN_RTR_DATA;   // 设置传输数据帧
  TxMessage.DLC = 4;              // 设置数据长度

  if (HAL_CAN_AddTxMessage(&hcan2, &TxMessage, data, &TxMailbox) != HAL_OK)
  {
    Error_Handler();
  }
}

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef* hcan)
{
  if (hcan == &hcan2) 
  {  
    handleCANPendingMessage();
  }
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef* htim)
{
  if (htim == &htim3) 
  {
    handleTimerPeriodElapsed();
  }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
