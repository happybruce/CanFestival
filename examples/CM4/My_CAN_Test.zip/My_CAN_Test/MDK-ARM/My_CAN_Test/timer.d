my_can_test/timer.o: ..\Core\CanFestival\src\timer.c \
  ..\Core\CanFestival\include\timer.h \
  ..\Core\CanFestival\include\cm4\timerscfg.h \
  ..\Core\CanFestival\include\cm4\applicfg.h \
  ..\Core\CanFestival\include\declaration.h \
  ..\Core\CanFestival\include\cm4\config.h
