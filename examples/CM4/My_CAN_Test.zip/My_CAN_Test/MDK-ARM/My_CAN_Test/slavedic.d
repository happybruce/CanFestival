my_can_test/slavedic.o: ..\Core\CanFestival\slavedic\slavedic.c \
  ..\Core\CanFestival\slavedic\slavedic.h \
  ..\Core\CanFestival\include\data.h \
  ..\Core\CanFestival\include\cm4\applicfg.h \
  ..\Core\CanFestival\include\def.h \
  ..\Core\CanFestival\include\cm4\config.h \
  ..\Core\CanFestival\include\can.h \
  ..\Core\CanFestival\include\declaration.h \
  ..\Core\CanFestival\include\objdictdef.h \
  ..\Core\CanFestival\include\objacces.h \
  ..\Core\CanFestival\include\sdo.h ..\Core\CanFestival\include\timer.h \
  ..\Core\CanFestival\include\cm4\timerscfg.h \
  ..\Core\CanFestival\include\pdo.h ..\Core\CanFestival\include\states.h \
  ..\Core\CanFestival\include\lifegrd.h \
  ..\Core\CanFestival\include\sync.h \
  ..\Core\CanFestival\include\nmtSlave.h \
  ..\Core\CanFestival\include\nmtMaster.h \
  ..\Core\CanFestival\include\emcy.h
