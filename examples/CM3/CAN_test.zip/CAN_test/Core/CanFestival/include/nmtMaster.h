/*
This file is part of CanFestival, a library implementing CanOpen Stack. 

Copyright (C): Edouard TISSERANT and Francis DUPIN

See COPYING file for copyrights details.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/** @defgroup networkmanagement Network Management
 *  @ingroup userapi
 */
/** @defgroup nmtmaster NMT Master
 *  @brief NMT master provides mechanisms that control and monitor the state of nodes and their behavior in the network.
 *  @ingroup networkmanagement
 */
 
#ifndef __NMT_MASTER_H__
#define __NMT_MASTER_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "applicfg.h"
#include "declaration.h"



/** 
 * @ingroup nmtmaster
 * @brief Transmit an NMT message to the slave identified by nodeId on the CAN bus.
 * 
 * @param d Pointer to a CAN object data structure
 * @param nodeId Id of the slave node
 * @param cs State change command
 * 
 * Allowed states :
 *  - cs =  NMT_Start_Node               // Put the node in operational mode
 *  - cs =  NMT_Stop_Node                // Put the node in stopped mode
 *  - cs =  NMT_Enter_PreOperational     // Put the node in pre_operational mode  
 *  - cs =  NMT_Reset_Node               // Put the node in initialization mode
 *  - cs =  NMT_Reset_Comunication       // Put the node in initialization mode
 *  
 * The mode is changed according to the slave state machine:
 *  - initialisation  ---> pre-operational (Automatic transition)
 *  - pre-operational <--> operational
 *  - pre-operational <--> stopped
 *  - pre-operational, operational, stopped -> initialisation
 * 
 * @return Error code
 *         - 0 if the NMT message was sent
 *         - 1 if an error occurs
 */
UNS8 masterSendNMTstateChange(CO_Data* d, UNS8 nodeId, UNS8 cs);

/**
 * @ingroup nmtmaster 
 * @brief Transmit a NodeGuard message to the slave identified by nodeId on the CAN bus.
 * 
 * @param d Pointer to a CAN object data structure
 * @param nodeId Id of the slave node
 * @return
 *         - 0 is returned if the NodeGuard message was sent.
 *         - 1 is returned if an error occurs.
 */
UNS8 masterSendNMTnodeguard(CO_Data* d, UNS8 nodeId);

/** 
 * @ingroup nmtmaster
 * @brief Request the state of the slave node identified by nodeId on the CAN bus.
 * 
 * To request states of all nodes on the network (NMT broadcast), nodeId must be 0.
 * @param d Pointer to a CAN object data structure
 * @param nodeId Id of the slave node
 */
UNS8 masterRequestNodeState(CO_Data* d, UNS8 nodeId);

#ifdef __cplusplus
}
#endif

#endif /* __NMT_MASTER_H__ */
