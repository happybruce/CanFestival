can_test/timer.o: ..\Core\CanFestival\src\timer.c \
  ..\Core\CanFestival\include\timer.h \
  ..\Core\CanFestival\include\cm3\timerscfg.h \
  ..\Core\CanFestival\include\cm3\applicfg.h \
  ..\Core\CanFestival\include\declaration.h \
  ..\Core\CanFestival\include\cm3\config.h
